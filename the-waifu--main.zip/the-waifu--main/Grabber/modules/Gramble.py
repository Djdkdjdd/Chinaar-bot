import random
import time
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler, CallbackQueryHandler
from Grabber import application, user_collection


async def gamble(update, context):
    # Retrieve user's balance
    user_id = update.effective_user.id
    user = await user_collection.find_one({'id': user_id})
    balance = user.get('balance', 0)

    if len(context.args) != 2:
        await update.message.reply_text("Usage: /gamble <amount> <l/r>")
        return

    try:
        amount = int(context.args[0])
        choice = context.args[1].lower()
    except ValueError:
        await update.message.reply_text("Invalid amount.")
        return

    if choice not in ['l', 'r']:
        await update.message.reply_text("Invalid choice. Please use /gamble l/r.")
        return


    
    min_bet = int(balance * 0.07)
    if amount < min_bet:
        await update.message.reply_text(f"Please gamble at least 7% of your balance, which is Ŧ{min_bet}.")
        return

    
    coin_side = random.choice(['l', 'r'])
    if coin_side == choice:
        # User wins
        message = f"🤩 You chose {choice} and won Ŧ{amount}.\nCoin was in {coin_side} hand."
        await update.message.reply_photo(photo="https://telegra.ph/file/889fb66c41a9ead354c59.jpg", caption=message)
        # Update user's balance by adding the winning amount
        new_balance = balance + amount
        await user_collection.update_one({'id': user_id}, {'$set': {'balance': new_balance}})
    else:
        # User loses
        message = f"🥲 You chose {choice} and lost Ŧ{amount}.\nCoin was in {coin_side} hand."
        await update.message.reply_photo(photo="https://telegra.ph/file/99a98f60b22759857056a.jpg", caption=message)
        # Update user's balance by deducting the gambling amount
        new_balance = balance - amount
        await user_collection.update_one({'id': user_id}, {'$set': {'balance': new_balance}})

# Add the command handler to your application
application.add_handler(CommandHandler("gamble", gamble))
