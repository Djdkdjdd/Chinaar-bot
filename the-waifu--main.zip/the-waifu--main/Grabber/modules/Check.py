from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler
from Grabber import application, db

# Command to check waifu information
async def check(update, context):
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /check <waifu_id>")
        return

    waifu_id = context.args[0]
    
    # Retrieve waifu information from the database based on the waifu ID
    waifu_info = await db.waifus.find_one({'waifu_id': waifu_id})
    if waifu_info:
        # Extract waifu details
        name = waifu_info.get('name', 'Unknown')
        game = waifu_info.get('game', 'Unknown')
        rarity = waifu_info.get('rarity', 'Unknown')
        picked_times = waifu_info.get('picked_times', 0)
        image_url = waifu_info.get('image_url', '')

        # Compose waifu information message
        message = f"𝙇𝙤𝙤𝙠 𝘼𝙩 𝙏𝙝𝙞𝙨 pick ‼️\n\n" \
                  f"✨: {name}\n" \
                  f"⛩: {game}\n" \
                  f"🔴 {rarity}\n\n" \
                  f"Globally picked {picked_times} Times..."

        # Send waifu information with the image
        if image_url:
            await update.message.reply_photo(photo=image_url, caption=message)
        else:
            await update.message.reply_text(message)
    else:
        await update.message.reply_text("Waifu information not found or invalid ID.")

# Add the command handler to your application
application.add_handler(CommandHandler("check", check))
