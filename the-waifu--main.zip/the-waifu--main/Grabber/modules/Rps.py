import random
from uuid import uuid4
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import CommandHandler, CallbackQueryHandler, InlineQueryHandler
from Grabber import application, user_collection

# Command to start the Rock-Paper-Scissors game
async def start_rps(update, context):
    # Retrieve user's balance
    user_id = update.effective_user.id
    user = await user_collection.find_one({'id': user_id})
    balance = user.get('balance', 0)

    # Check if the user has enough balance to play
    if balance <= 0:
        await update.message.reply_text("You don't have enough balance to play Rock-Paper-Scissors.")
        return

    # Deduct 5% of user's balance for playing RPS
    bet_amount = max(int(balance * 0.05), 1)  # Ensure bet amount is at least 1
    await user_collection.update_one({'id': user_id}, {'$inc': {'balance': -bet_amount}})

    keyboard = [
        [InlineKeyboardButton("Rock", callback_data=f'rps_rock_{bet_amount}'), 
         InlineKeyboardButton("Paper", callback_data=f'rps_paper_{bet_amount}'), 
         InlineKeyboardButton("Scissors", callback_data=f'rps_scissors_{bet_amount}')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Choose your move:", reply_markup=reply_markup)

# Callback function for handling user choices in the RPS game
async def rps_callback(update, context):
    query = update.callback_query
    user_id = update.effective_user.id
    _, user_choice, bet_amount = query.data.split('_')
    bet_amount = int(bet_amount)

    bot_choice = random.choice(["rock", "paper", "scissors"])

    if user_choice == bot_choice:
        await query.edit_message_text("It's a tie!")
    elif (user_choice == 'rock' and bot_choice == 'scissors') or \
         (user_choice == 'paper' and bot_choice == 'rock') or \
         (user_choice == 'scissors' and bot_choice == 'paper'):
        await query.edit_message_text("You win!")
        # Update user's balance by adding the bet amount
        await user_collection.update_one({'id': user_id}, {'$inc': {'balance': bet_amount}})
    else:
        await query.edit_message_text("You lose!")
        # Update user's balance by deducting the bet amount
        await user_collection.update_one({'id': user_id}, {'$inc': {'balance': -bet_amount}})

# Command to tag another user for RPS
async def tag_rps(update, context):
    if len(context.args) != 1:
        await update.message.reply_text("Invalid usage. Please use /tag_rps <bet_amount>")
        return

    try:
        bet_amount = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid bet amount.")
        return

    # Retrieve user's ID
    user_id = update.effective_user.id

    # Ask the tagged user to accept or reject the RPS challenge
    message = f"Tagging user {user_id}. Do you accept the Rock-Paper-Scissors challenge with a bet of {bet_amount} tokens?"
    accept_keyboard = [[InlineKeyboardButton("Accept", callback_data=f'rps_accept_{user_id}_{bet_amount}'),
                        InlineKeyboardButton("Cancel", callback_data=f'rps_cancel_{user_id}_{bet_amount}')]]
    reply_markup = InlineKeyboardMarkup(accept_keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)

# Command to handle accept or cancel from tagged user
async def accept_cancel(update, context):
    query = update.callback_query
    action, user_id, bet_amount = query.data.split('_')[1:]

    if action == 'accept':
        await start_rps(update, context)
    else:
        await query.edit_message_text(f"You have canceled the challenge with user {user_id}.")

# Add the command handlers to your application
application.add_handler(CommandHandler("rps", start_rps))
application.add_handler(CommandHandler("tag_rps", tag_rps))
application.add_handler(CallbackQueryHandler(rps_callback))
application.add_handler(CallbackQueryHandler(accept_cancel))
