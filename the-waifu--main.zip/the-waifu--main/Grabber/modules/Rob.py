from telegram.ext import CommandHandler
from Grabber import application, user_collection
import time
import random

# Define a dictionary to keep track of cooldowns for each user
rob_cooldowns = {}
passive_cooldowns = {}
passive_users = set()

async def rob(update, context):
    user_id = update.effective_user.id

    # Check if the user is in passive mode
    if user_id in passive_users:
        await update.message.reply_text("You are currently in passive mode. Use /passive_off to disable passive mode.")
        return

    # Check if the user is still in cooldown
    if user_id in rob_cooldowns and (time.time() - rob_cooldowns[user_id]) < 3600:
        await update.message.reply_text("Please wait 1 hour before robbing again.")
        return

    # Check if the command includes a tagged user
    if not update.message.reply_to_message or not update.message.reply_to_message.from_user:
        await update.message.reply_text("Please reply to a user's message to attempt to rob them.")
        return

    target_user_id = update.message.reply_to_message.from_user.id

    # Get the target user's balance
    target_user = await user_collection.find_one({'id': target_user_id}, projection={'balance': 1})

    if not target_user or 'balance' not in target_user:
        await update.message.reply_text("The target user doesn't have any tokens to rob.")
        return

    # Calculate the amount to rob (10% of the target user's balance)
    amount_to_rob = target_user['balance'] * 0.10

    # Adjust the success rate based on your desired probability (e.g., 20% chance of success)
    success_rate = 70  # Set the success rate in percentage

    # Randomly generate a number to determine success or failure
    success_threshold = success_rate / 100.0
    success_roll = random.uniform(0, 1)

    if success_roll <= success_threshold:
        # Rob successful
        await user_collection.update_one({'id': user_id}, {'$inc': {'balance': amount_to_rob}})  # Update the robber's balance
        await user_collection.update_one({'id': target_user_id}, {'$inc': {'balance': -amount_to_rob}})  # Update the target's balance
        rob_cooldowns[user_id] = time.time()  # Set cooldown for the user
        await update.message.reply_text(f"You successfully robbed {amount_to_rob:.2f} tokens from {update.message.reply_to_message.from_user.username}!")
    else:
        # Rob unsuccessful
        # Deduct 5% of the attempted robbery amount as penalty
        penalty = amount_to_rob * 0.02
        await user_collection.update_one({'id': user_id}, {'$inc': {'balance': -penalty}})  # Deduct penalty from the robber's balance
        # Add 5% of the penalty amount to the target user's balance
        await user_collection.update_one({'id': target_user_id}, {'$inc': {'balance': penalty}})
        await update.message.reply_text(f"Failed to rob. You were penalized {penalty:.2f} tokens.")

# Add handler for the /rob command
application.add_handler(CommandHandler("rob", rob))

# Add handler for passive mode on
async def passive_on(update, context):
    user_id = update.effective_user.id
    # Check if the user is still in cooldown
    if user_id in passive_cooldowns and (time.time() - passive_cooldowns[user_id]) < 60:
        await update.message.reply_text("Please wait 1 minute before enabling passive mode again.")
        return
    passive_users.add(user_id)
    passive_cooldowns[user_id] = time.time()  # Set cooldown for the user
    await update.message.reply_text("Passive mode enabled. You will not be able to rob other users until you disable passive mode.")

# Add handler for passive mode off
async def passive_off(update, context):
    user_id = update.effective_user.id
    # Check if the user is still in cooldown
    if user_id in passive_cooldowns and (time.time() - passive_cooldowns[user_id]) < 60:
        await update.message.reply_text("Please wait 1 minute before disabling passive mode again.")
        return
    passive_users.remove(user_id)
    passive_cooldowns[user_id] = time.time()  # Set cooldown for the user
    await update.message.reply_text("Passive mode disabled. You can now rob other users.")

# Add handlers for passive mode commands
application.add_handler(CommandHandler("passive_on", passive_on))
application.add_handler(CommandHandler("passive_off", passive_off))
