from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler
from Grabber import application, user_collection
import random

# Command to start the dart game
async def dart(update, context):
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /dart <bet_amount>")
        return

    try:
        bet_amount = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid bet amount.")
        return

    # Check if the bet amount is valid
    if bet_amount <= 0:
        await update.message.reply_text("Please enter a valid bet amount.")
        return

    # Simulate dart throw (1 in 3 chance to win)
    if random.randint(1, 3) == 1:
        # User wins
        await update.message.reply_text("🎯 Dart landed inside the target! You won!")
        # Update user's balance by adding the bet amount
        await user_collection.update_one({'id': update.effective_user.id}, {'$inc': {'balance': bet_amount}})
    else:
        # User loses
        await update.message.reply_text("🎯 Dart missed the target! You lost!")
        # Update user's balance by deducting the bet amount
        await user_collection.update_one({'id': update.effective_user.id}, {'$inc': {'balance': -bet_amount}})

# Add the command handler to your application
application.add_handler(CommandHandler("dart", dart))
