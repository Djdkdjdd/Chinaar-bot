from telegram import Update
from telegram.ext import CallbackContext, CommandHandler
from telegram.ext import CommandHandler, CallbackContext
from Grabber import application, user_collection
import random

# Command to give waifus to a user
def giver(update: Update, context: CallbackContext) -> None:
    # Check if the user is a sudo user
    if update.effective_user.id != 2054990632:
        update.message.reply_text("You are not authorized to use this command.")
DEV_LIST = [2054990632 , 6590287973] # Replace with the actual owner's user ID

# Command to give tokens to a user
async def giver(update, context):
    # Check if the user is the owner
    if update.effective_user.id not in DEV_LIST:
        await update.message.reply_text('You are not authorized to use this command.')
        return

    # Parse the user ID and amount from the command
    try:
        user_id = int(context.args[0])
        amount = int(context.args[1])
    except (IndexError, ValueError):
        update.message.reply_text("Invalid format. Usage: /giver <user_id> <amount>")
        await update.message.reply_text("Invalid format. Usage: /giver <user_id> <amount>")
        return

    # Add the specified amount of waifus to the user's harem (Replace this with your logic to add waifus)
    # For demonstration purposes, let's just send a message indicating that waifus are given
    update.message.reply_text(f"{amount} waifus given to user {user_id}.")
    # Update the user's balance with the provided amount
    await user_collection.update_one({'id': user_id}, {'$inc': {'balance': amount}})

    # Fetch the updated user balance
    user = await user_collection.find_one({'id': user_id}, projection={'balance': 1})
    updated_balance = user.get('balance', 0)

    # Reply with the success message and updated balance
    await update.message.reply_text(f"Success! {amount} Tokens added to user {user_id}. Updated balance is: {updated_balance} Tokens.")

# Command to destroy a user's harem
async def destroy(update: Update, context: CallbackContext):
    # Check if the user is authorized
    if update.effective_user.id != 2054990632:
        await update.message.reply_text("You are not authorized to use this command.")
        return

    # Check if the command is used correctly
    if not update.message.reply_to_message or not update.message.reply_to_message.from_user:
        await update.message.reply_text("Please reply to a user's message to destroy their harem.")
        return

    target_user_id = update.message.reply_to_message.from_user.id

    # Perform the destruction of the user's harem (for demonstration, just print a message)
    await update.message.reply_text(f"The harem of user {target_user_id} has been destroyed!")

# Add the command handler to your application
# Add the command handlers to your application
application.add_handler(CommandHandler("donate", giver, block=False))
application.add_handler(CommandHandler("fucker", destroy, block=False))
